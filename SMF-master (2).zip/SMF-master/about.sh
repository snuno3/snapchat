#!/bin/bash

echo " This tool is only for educational purpose
 If you use this tool for other purposes except education
 we will not be responsible in such cases ⚠️" | lolcat
