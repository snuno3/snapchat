



# TECH COCHI
[![20200703_192925.png](https://img.imageupload.net/2020/07/03/20200703_192925.png)]

# SMF HACKING TOOL 
[![IMG_20200624_014109.md.jpg](https://imagehost.imageupload.net/2020/06/24/IMG_20200624_014109.md.jpg)](https://www.imageupload.net/image/9pFIc)

## Installation Commands ↙️
* `apt update`
* `apt upgrade`
* `pkg install git`
* `git clone https://github.com/rixon-cochi/SMF.git`
* `cd SMF`
* `bash install.sh`
* `bash smf.sh`

# INSTALLING VIDEO
[![20200703_232644.jpg](https://img.imageupload.net/2020/07/03/20200703_232644.jpg)](https://youtu.be/1cZuT0MagVU)

### <<< If you copy , Then Give me The Credits >>>

## Features :
#### [+] Latest Login Pages !
#### [+] New Instagram Auto Follower Page !
#### [+] 4 Port Forwarding Options !
#### [+] Easy for Beginners !

## Tunelling Options :
#### > Localhost (127.0.0.1)
#### > NGROK (https://ngrok.com)
#### > SERVEO (https://serveo.net)
#### > LOCALHOSTRUN (https://localhost.run)

## Find Me on :
[![Github](https://img.shields.io/badge/Github-TECH--COCHI-green?style=for-the-badge&logo=github)](https://github.com/rixon-cochi)
[![TELEGRAM](https://img.shields.io/badge/TELEGRAM-TECH--COCHI-blue?style=for-the-badge&logo=telegram)](https://t.me/techcochiyoutuber)
[![Youtube](https://img.shields.io/badge/Youtube-TECH--COCHI-red?style=for-the-badge&logo=youtube)](https://youtube.com/c/HYDRAGAMING4U)



